/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./backbutton/BackButton.tsx"
/*!***********************************!*\
  !*** ./backbutton/BackButton.tsx ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   BackButton: () => (/* binding */ BackButton)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar BackButton = _ref => {\n  var {\n    labelText,\n    onBackClick,\n    backgroundColor = 'transparent',\n    fontWeight = 450,\n    showButtonIcon = true,\n    fontColor = '#3B3B48',\n    fontSize = '20px'\n  } = _ref;\n  var [isHovered, setIsHovered] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var containerStyle = {\n    display: 'flex',\n    justifyContent: 'flex-start',\n    alignItems: 'center',\n    gap: '12px',\n    cursor: 'pointer',\n    userSelect: 'none',\n    backgroundColor: backgroundColor,\n    padding: '0px',\n    borderRadius: '8px',\n    width: '100%',\n    height: '100%'\n  };\n  var buttonCircleStyle = {\n    width: '40px',\n    height: '40px',\n    borderRadius: '50%',\n    backgroundColor: isHovered ? '#F9FAFB' : '#FFFFFF',\n    boxShadow: isHovered ? '0px 4px 12px rgba(0, 0, 0, 0.15)' : '0px 2px 4px rgba(0, 0, 0, 0.1)',\n    display: showButtonIcon ? 'flex' : 'none',\n    alignItems: 'center',\n    justifyContent: 'center',\n    transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',\n    transform: isHovered ? 'translateY(-2px) scale(1.1)' : 'translateY(0) scale(1)'\n  };\n  var iconStyle = {\n    width: '16px',\n    height: '16px',\n    color: '#E02424',\n    // Red color for chevron\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center'\n  };\n  var labelStyle = {\n    fontFamily: \"'Suisse Int\\\\'l', sans-serif\",\n    fontWeight: fontWeight,\n    fontSize: fontSize,\n    lineHeight: '32px',\n    letterSpacing: '0%',\n    verticalAlign: 'middle',\n    color: fontColor,\n    margin: 0\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: containerStyle,\n    onClick: onBackClick\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: buttonCircleStyle,\n    onMouseEnter: () => setIsHovered(true),\n    onMouseLeave: () => setIsHovered(false)\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    style: iconStyle,\n    viewBox: \"0 0 24 24\",\n    fill: \"none\",\n    stroke: \"currentColor\",\n    strokeWidth: \"2.5\",\n    strokeLinecap: \"round\",\n    strokeLinejoin: \"round\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M15 18l-6-6 6-6\"\n  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    style: labelStyle\n  }, labelText));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./backbutton/BackButton.tsx?\n}");

/***/ },

/***/ "./backbutton/index.ts"
/*!*****************************!*\
  !*** ./backbutton/index.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   backbutton: () => (/* binding */ backbutton)\n/* harmony export */ });\n/* harmony import */ var _BackButton__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BackButton */ \"./backbutton/BackButton.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass backbutton {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._trigger = false;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;\n    var props = {\n      labelText: (_a = context.parameters.LabelText.raw) !== null && _a !== void 0 ? _a : \"Create External Entity\",\n      onBackClick: this.handleBackClick.bind(this),\n      backgroundColor: (_c = (_b = context.parameters.BackgroundColor) === null || _b === void 0 ? void 0 : _b.raw) !== null && _c !== void 0 ? _c : 'transparent',\n      fontWeight: (_e = (_d = context.parameters.FontWeight) === null || _d === void 0 ? void 0 : _d.raw) !== null && _e !== void 0 ? _e : '450',\n      fontColor: (_g = (_f = context.parameters.FontColor) === null || _f === void 0 ? void 0 : _f.raw) !== null && _g !== void 0 ? _g : '#3B3B48',\n      fontSize: (_j = (_h = context.parameters.FontSize) === null || _h === void 0 ? void 0 : _h.raw) !== null && _j !== void 0 ? _j : '20px',\n      showButtonIcon: (_l = (_k = context.parameters.ShowButtonIcon) === null || _k === void 0 ? void 0 : _k.raw) !== null && _l !== void 0 ? _l : true\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_BackButton__WEBPACK_IMPORTED_MODULE_0__.BackButton, props);\n  }\n  handleBackClick() {\n    this._trigger = !this._trigger;\n    this.notifyOutputChanged();\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      Trigger: this._trigger\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./backbutton/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./backbutton/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('backbutton.backbutton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.backbutton);
} else {
	var backbutton = backbutton || {};
	backbutton.backbutton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.backbutton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}