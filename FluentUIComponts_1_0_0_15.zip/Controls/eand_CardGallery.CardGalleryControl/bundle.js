/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./CardGalleryControl/components/CardsGalleryActions.tsx"
/*!***************************************************************!*\
  !*** ./CardGalleryControl/components/CardsGalleryActions.tsx ***!
  \***************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CardsGalleryActions: () => (/* binding */ CardsGalleryActions)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\n/* ---------------- HELPERS ---------------- */\n// ✅ ADD IT HERE (outside component)\nfunction chunkCards(items, size) {\n  var result = [];\n  for (var i = 0; i < items.length; i += size) {\n    result.push(items.slice(i, i + size));\n  }\n  return result;\n}\nvar CARD_WIDTH = 392;\nvar CARD_GAP = 24;\n/* ---------------- FIGMA ARROW ICON ---------------- */\nvar ArrowUpRightIcon = _ref => {\n  var {\n    size = 16\n  } = _ref;\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    width: size,\n    height: size,\n    viewBox: \"0 0 16 16\",\n    fill: \"none\",\n    xmlns: \"http://www.w3.org/2000/svg\",\n    \"aria-hidden\": \"true\",\n    focusable: \"false\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M13.3334 3.33333V10C13.3334 10.368 13.0354 10.6667 12.6668 10.6667C12.2981 10.6667 12.0001 10.368 12.0001 10V4.94271L4.47146 12.4714C4.34146 12.6014 4.17077 12.6667 4.00011 12.6667C3.82944 12.6667 3.65875 12.6014 3.52875 12.4714C3.26809 12.2107 3.26809 11.7893 3.52875 11.5286L11.0574 4H6.00011C5.63144 4 5.33344 3.70133 5.33344 3.33333C5.33344 2.96533 5.63144 2.66667 6.00011 2.66667H12.6668C12.7534 2.66667 12.8402 2.6846 12.9215 2.71794C13.0848 2.78527 13.2148 2.91528 13.2822 3.07861C13.3162 3.15995 13.3334 3.24667 13.3334 3.33333Z\",\n    fill: \"#E00800\"\n  }));\n};\n/* ---------------- COMPONENT ---------------- */\n/*\nexport const CardsGalleryActions: React.FC<ICardsGalleryActionsProps> = ({\n    cards,\n    onCardClick\n}) => {\n    const [hoveredIndex, setHoveredIndex] = React.useState<number | null>(null);\n    const [focusedIndex, setFocusedIndex] = React.useState<number | null>(null);\n    const [activeIndex, setActiveIndex] = React.useState<number | null>(null);\n\n    return (\n        <div style={styles.root}>\n            <div style={styles.grid}>\n                {cards.map((card, index) => {\n                    const isHovered = hoveredIndex === index;\n                    const isFocused = focusedIndex === index;\n                    const isActive = activeIndex === index;\n\n                    const cardStyle: React.CSSProperties = {\n                        ...styles.card,\n                        ...(isHovered && !isFocused ? styles.cardHover : {}),\n                        ...(isFocused ? styles.cardFocus : {}),\n                        ...(isActive ? styles.cardActive : {})\n                    };\n\n                    return (\n                        <div\n                            key={index}\n                            role=\"button\"\n                            tabIndex={0}\n                            aria-label={card.title}\n                            aria-pressed={false}\n                            style={cardStyle}\n                            onMouseEnter={() => setHoveredIndex(index)}\n                            onMouseLeave={() => setHoveredIndex(null)}\n                            onFocus={() => setFocusedIndex(index)}\n                            onBlur={() => setFocusedIndex(null)}\n                            onMouseDown={() => setActiveIndex(index)}\n                            onMouseUp={() => setActiveIndex(null)}\n                            onTouchStart={() => setActiveIndex(index)}\n                            onTouchEnd={() => setActiveIndex(null)}\n                            onClick={() => onCardClick(card.actionKey)}\n                            onKeyDown={(e) => {\n                                if (e.key === \"Enter\" || e.key === \" \") {\n                                    e.preventDefault();\n                                    onCardClick(card.actionKey);\n                                }\n                            }}\n                        >\n                           \n                            <div style={styles.arrowIcon}>\n                                <ArrowUpRightIcon />\n                            </div>\n\n                            <div style={styles.content}>\n                                <span style={styles.title}>{card.title}</span>\n                                <span style={styles.subtitle}>{card.subtitle}</span>\n                            </div>\n                        </div>\n                    );\n                })}\n            </div>\n        </div>\n    );\n};\n\n*/\nvar CardsGalleryActions = _ref2 => {\n  var {\n    cards,\n    cardsPerRow,\n    onCardClick\n  } = _ref2;\n  var [hoveredIndex, setHoveredIndex] = react__WEBPACK_IMPORTED_MODULE_0__.useState(null);\n  var [focusedIndex, setFocusedIndex] = react__WEBPACK_IMPORTED_MODULE_0__.useState(null);\n  var [activeIndex, setActiveIndex] = react__WEBPACK_IMPORTED_MODULE_0__.useState(null);\n  var containerRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);\n  var [availableWidth, setAvailableWidth] = react__WEBPACK_IMPORTED_MODULE_0__.useState(0);\n  // ✅ ADD THIS LINE HERE\n  //const rows = chunkCards(cards, cardsPerRow);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (!containerRef.current) return;\n    var observer = new ResizeObserver(entries => {\n      var entry = entries[0];\n      if (entry) {\n        setAvailableWidth(entry.contentRect.width);\n      }\n    });\n    observer.observe(containerRef.current);\n    return () => observer.disconnect();\n  }, []);\n  //const safeCardsPerRow = Math.max(1, cardsPerRow || 1);\n  //const rows = chunkCards(cards, safeCardsPerRow);\n  var maxCardsPerRow = Math.max(1, cardsPerRow || 1);\n  var possibleCards = Math.floor((availableWidth + CARD_GAP) / (CARD_WIDTH + CARD_GAP));\n  var effectiveCardsPerRow = Math.max(1, Math.min(maxCardsPerRow, possibleCards));\n  var rows = chunkCards(cards, effectiveCardsPerRow);\n  return (\n    /*#__PURE__*/\n    //<div style={styles.root}>\n    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      ref: containerRef,\n      style: styles.root\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        padding: 16\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: styles.section\n    }, rows.map((row, rowIndex) => (\n    /*#__PURE__*/\n    // <div key={rowIndex} style={styles.row}>\n    react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      key: rowIndex,\n      style: Object.assign(Object.assign({}, styles.row), {\n        /*\n                                    maxWidth:\n                                        cardsPerRow * CARD_WIDTH +\n                                        (cardsPerRow - 1) * CARD_GAP,\n        */\n        width: \"100%\"\n      })\n    }, row.map((card, index) => {\n      //const cardIndex = rowIndex * cardsPerRow + index;\n      var cardIndex = rowIndex * effectiveCardsPerRow + index;\n      var isHovered = hoveredIndex === cardIndex;\n      var isFocused = focusedIndex === cardIndex;\n      var isActive = activeIndex === cardIndex;\n      var cardStyle = Object.assign(Object.assign(Object.assign(Object.assign({}, styles.card), isHovered ? styles.cardHover : {}), isFocused ? styles.cardFocus : {}), isActive ? styles.cardActive : {});\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n        key: cardIndex,\n        role: \"button\",\n        tabIndex: 0,\n        \"aria-label\": card.title,\n        \"aria-pressed\": false,\n        style: cardStyle,\n        onMouseEnter: () => setHoveredIndex(cardIndex),\n        onMouseLeave: () => setHoveredIndex(null),\n        onFocus: () => setFocusedIndex(cardIndex),\n        onBlur: () => setFocusedIndex(null),\n        onMouseDown: () => setActiveIndex(cardIndex),\n        onMouseUp: () => setActiveIndex(null),\n        onTouchStart: () => setActiveIndex(cardIndex),\n        onTouchEnd: () => setActiveIndex(null),\n        onKeyDown: e => {\n          if (e.key === \"Enter\" || e.key === \" \") {\n            e.preventDefault();\n            onCardClick(card.actionKey);\n          }\n        },\n        onClick: () => onCardClick(card.actionKey)\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n        style: styles.arrowIcon\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(ArrowUpRightIcon, null)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n        style: styles.content\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n        style: styles.title\n      }, card.title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n        style: styles.subtitle\n      }, card.subtitle)));\n    })))))))\n  );\n};\n/* ---------------- STYLES ---------------- */\nvar styles = {\n  /*\n      root: {\n          width: \"100%\",\n          padding: \"16px\",\n          boxSizing: \"border-box\",\n          fontFamily: \"Arial\"\n      },*/\n  root: {\n    width: \"100%\",\n    boxSizing: \"border-box\",\n    fontFamily: \"Arial\"\n  },\n  /*\n      grid: {\n          display: \"grid\",\n          //gridTemplateColumns: \"repeat(auto-fit, minmax(280px, 1fr))\",\n          gridTemplateColumns: \"repeat(3, minmax(0, 1fr))\",\n  \n          gap: \"16px\",\n          alignItems: \"stretch\" // ✅ ensures equal row height\n      },*/\n  /*\n      grid: {\n          display: \"grid\",\n          gridTemplateColumns: \"repeat(3, 392px)\",\n          gap: \"16px\",\n          justifyContent: \"center\"\n      },*/\n  /*\n      card: {\n          position: \"relative\",\n          display: \"flex\",\n          alignItems: \"center\",\n          padding: \"20px 24px\",\n          gap: \"12px\",\n          backgroundColor: \"#FAFAFB\",\n          borderRadius: \"16px\",\n          minHeight: \"88px\",\n          boxSizing: \"border-box\",\n          cursor: \"pointer\",\n          outline: \"none\",\n          transition: \"box-shadow 0.2s ease, transform 0.2s ease\"\n      },*/\n  card: {\n    flex: \"1 1 0\",\n    // 🔑 allow equal growth\n    minWidth: \"392px\",\n    // preferred Figma width\n    height: \"88px\",\n    position: \"relative\",\n    display: \"flex\",\n    alignItems: \"center\",\n    padding: \"20px 24px\",\n    gap: \"12px\",\n    backgroundColor: \"#FAFAFB\",\n    borderRadius: \"16px\",\n    boxSizing: \"border-box\",\n    cursor: \"pointer\",\n    outline: \"none\",\n    transition: \"box-shadow 0.2s ease, transform 0.2s ease\"\n  },\n  section: {\n    display: \"flex\",\n    flexDirection: \"column\",\n    gap: \"24px\",\n    width: \"100%\",\n    alignItems: \"flex-start\" // ✅ FIX\n  },\n  row: {\n    display: \"flex\",\n    flexDirection: \"row\",\n    gap: \"24px\",\n    justifyContent: \"space-between\",\n    // 🔥 Figma behavior\n    flexWrap: \"nowrap\"\n  },\n  /* Hover elevation */\n  cardHover: {\n    boxShadow: \"0px 6px 16px rgba(25, 19, 41, 0.12)\",\n    transform: \"translateY(-2px)\"\n  },\n  /* Focus ring */\n  cardFocus: {\n    boxShadow: \"0px 0px 0px 3px rgba(224, 8, 0, 0.35)\"\n  },\n  /* Active / pressed */\n  cardActive: {\n    transform: \"translateY(0)\",\n    boxShadow: \"0px 3px 8px rgba(25, 19, 41, 0.18)\"\n  },\n  arrowIcon: {\n    position: \"absolute\",\n    top: \"20px\",\n    right: \"24px\",\n    width: \"16px\",\n    height: \"16px\",\n    display: \"flex\",\n    alignItems: \"center\",\n    justifyContent: \"center\",\n    pointerEvents: \"none\"\n  },\n  /*\n      content: {\n          display: \"flex\",\n          flexDirection: \"column\",\n          gap: \"4px\",\n          paddingRight: \"24px\",\n          flex: 1\n      },\n  \n      title: {\n          fontSize: \"16px\",\n          fontWeight: 700,\n          lineHeight: \"24px\",\n          color: \"#191329\"\n      },\n  \n      subtitle: {\n          fontSize: \"14px\",\n          fontWeight: 400,\n          lineHeight: \"20px\",\n          color: \"#191329\"\n      }\n  \n  */\n  /*\n      content: {\n          display: \"flex\",\n          flexDirection: \"column\",\n          alignItems: \"flex-start\",   // ✅ explicit left align\n          gap: \"4px\",\n          paddingRight: \"24px\",\n          flex: 1,\n          minWidth: 0                // ✅ REQUIRED for ellipsis in flex\n      },\n  */\n  content: {\n    display: \"flex\",\n    flexDirection: \"column\",\n    justifyContent: \"center\",\n    alignItems: \"flex-start\",\n    // ✅ Figma: left aligned\n    gap: \"4px\",\n    paddingRight: \"24px\",\n    flex: 1,\n    minWidth: 0\n  },\n  /*\n      title: {\n          fontSize: \"16px\",\n          fontWeight: 700,\n          lineHeight: \"24px\",\n          color: \"#191329\",\n          textAlign: \"left\",\n          whiteSpace: \"nowrap\",      // optional but recommended\n          overflow: \"hidden\",\n          textOverflow: \"ellipsis\"\n      },\n  \n      subtitle: {\n          fontSize: \"14px\",\n          fontWeight: 400,\n          lineHeight: \"20px\",\n          color: \"#191329\",\n          textAlign: \"left\",\n          whiteSpace: \"nowrap\",      // ✅ no wrapping\n          overflow: \"hidden\",\n          textOverflow: \"ellipsis\"\n      }\n  */\n  title: {\n    fontSize: \"16px\",\n    fontWeight: 700,\n    lineHeight: \"24px\",\n    color: \"#191329\",\n    whiteSpace: \"nowrap\",\n    overflow: \"hidden\",\n    textOverflow: \"ellipsis\"\n  },\n  subtitle: {\n    fontSize: \"14px\",\n    fontWeight: 400,\n    lineHeight: \"20px\",\n    color: \"#191329\",\n    whiteSpace: \"nowrap\",\n    overflow: \"hidden\",\n    textOverflow: \"ellipsis\"\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CardGalleryControl/components/CardsGalleryActions.tsx?\n}");

/***/ },

/***/ "./CardGalleryControl/index.ts"
/*!*************************************!*\
  !*** ./CardGalleryControl/index.ts ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CardGalleryControl: () => (/* binding */ CardGalleryControl)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_CardsGalleryActions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/CardsGalleryActions */ \"./CardGalleryControl/components/CardsGalleryActions.tsx\");\n\n\nclass CardGalleryControl {\n  init(context, notifyOutputChanged) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /*\n      public updateView(\n          context: ComponentFramework.Context<IInputs>\n      ): React.ReactElement {\n  \n          let cards: CardItem[] = [];\n  \n          try {\n              const json = context.parameters.cardsJson?.raw;\n              if (json) {\n                  cards = JSON.parse(json) as CardItem[];\n              }\n          } catch (e) {\n              console.error(\"Invalid cards JSON\", e);\n          }\n  \n          return React.createElement(CardsGalleryActions, {\n              cards,\n              onCardClick: (key: string) => {\n                  this.selectedActionKey = key;\n                  this.notifyOutputChanged();\n              }\n          });\n      }*/\n  updateView(context) {\n    var _a, _b, _c;\n    var cards = [];\n    try {\n      var json = (_a = context.parameters.cardsJson) === null || _a === void 0 ? void 0 : _a.raw;\n      if (json) {\n        cards = JSON.parse(json);\n      }\n    } catch (e) {\n      console.error(\"Invalid cards JSON\", e);\n    }\n    var cardsPerRow = (_c = (_b = context.parameters.cardsPerRow) === null || _b === void 0 ? void 0 : _b.raw) !== null && _c !== void 0 ? _c : 3; // 👈 default to 3\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_CardsGalleryActions__WEBPACK_IMPORTED_MODULE_1__.CardsGalleryActions, {\n      cards,\n      cardsPerRow,\n      onCardClick: key => {\n        this.selectedActionKey = key;\n        this.notifyOutputChanged();\n      }\n    });\n  }\n  getOutputs() {\n    return {\n      selectedActionKey: this.selectedActionKey\n    };\n  }\n  destroy() {\n    // Cleanup if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CardGalleryControl/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./CardGalleryControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CardGallery.CardGalleryControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CardGalleryControl);
} else {
	var CardGallery = CardGallery || {};
	CardGallery.CardGalleryControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CardGalleryControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}