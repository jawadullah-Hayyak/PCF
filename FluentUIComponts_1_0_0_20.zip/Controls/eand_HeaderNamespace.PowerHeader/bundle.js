/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PowerHeader/HeaderApp.tsx"
/*!***********************************!*\
  !*** ./PowerHeader/HeaderApp.tsx ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   HeaderApp: () => (/* binding */ HeaderApp)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\n(0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.initializeIcons)();\nvar headerStackStyles = function headerStackStyles() {\n  var background = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#FFFFFF';\n  return {\n    root: {\n      background: background,\n      height: '70px',\n      padding: '0 20px',\n      boxShadow: '0 2px 4px rgba(0,0,0,0.05)',\n      width: '100%',\n      boxSizing: 'border-box'\n    }\n  };\n};\nvar roleTagClass = function roleTagClass() {\n  var bgColor = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#F3F2F1';\n  var textColor = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '#323130';\n  return (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyles)({\n    backgroundColor: bgColor,\n    color: textColor,\n    padding: '4px 12px',\n    borderRadius: '20px',\n    fontWeight: 600,\n    fontSize: '12px',\n    textTransform: 'uppercase',\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center'\n  });\n};\nvar iconButtonStyles = function iconButtonStyles() {\n  var color = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#323130';\n  return {\n    root: {\n      color: color,\n      borderRadius: '50%',\n      width: '40px',\n      height: '40px',\n      border: '1px solid #E1DFDD',\n      display: 'flex',\n      alignItems: 'center',\n      justifyContent: 'center',\n      backgroundColor: 'transparent'\n    },\n    rootHovered: {\n      color: color,\n      background: 'rgba(0,0,0,0.05)'\n    }\n  };\n};\nvar activeRoleClass = function activeRoleClass() {\n  var bgColor = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#0078d4';\n  var textColor = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '#ffffff';\n  return (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyles)({\n    backgroundColor: bgColor,\n    color: textColor,\n    padding: '6px 16px',\n    borderRadius: '20px',\n    fontWeight: 700,\n    fontSize: '14px',\n    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'\n  });\n};\nvar inactiveRoleClass = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyles)({\n  color: '#A19F9D',\n  padding: '6px 16px',\n  fontSize: '14px',\n  cursor: 'pointer'\n});\nvar HeaderApp = props => {\n  var {\n    username,\n    designation,\n    profileImageUrl,\n    userRole,\n    notificationCount = 0,\n    headerBackground,\n    iconColor,\n    roleBackgroundColor,\n    roleTextColor,\n    showCart = true,\n    showNotification = true\n  } = props;\n  var personaProps = {\n    imageUrl: profileImageUrl,\n    text: username,\n    secondaryText: designation,\n    size: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PersonaSize.size40,\n    presence: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PersonaPresence.online\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    horizontal: true,\n    verticalAlign: \"center\",\n    horizontalAlign: \"space-between\",\n    styles: headerStackStyles(headerBackground)\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    horizontal: true,\n    verticalAlign: \"center\",\n    tokens: {\n      childrenGap: 10\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    horizontal: true,\n    verticalAlign: \"center\",\n    className: (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyles)({\n      background: '#F3F2F1',\n      borderRadius: '25px',\n      padding: '2px'\n    })\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: userRole.toLowerCase() === 'employee' ? activeRoleClass(roleBackgroundColor, roleTextColor) : inactiveRoleClass,\n    style: userRole.toLowerCase() === 'employee' ? {\n      backgroundColor: roleBackgroundColor,\n      color: roleTextColor\n    } : {}\n  }, \"Employee\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: userRole.toLowerCase() === 'admin' ? activeRoleClass(roleBackgroundColor, roleTextColor) : inactiveRoleClass,\n    style: userRole.toLowerCase() === 'admin' ? {\n      backgroundColor: roleBackgroundColor,\n      color: roleTextColor\n    } : {}\n  }, \"Admin\"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {\n    horizontal: true,\n    verticalAlign: \"center\",\n    tokens: {\n      childrenGap: 15\n    }\n  }, showNotification && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      position: 'relative',\n      width: '40px',\n      height: '40px'\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {\n    iconProps: {\n      iconName: 'Ringer'\n    },\n    styles: iconButtonStyles(iconColor)\n  }), notificationCount > 0 && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: {\n      position: 'absolute',\n      top: '-2px',\n      right: '-2px',\n      minWidth: '18px',\n      height: '18px',\n      padding: '0 4px',\n      fontSize: '10px',\n      backgroundColor: '#d13438',\n      color: '#ffffff',\n      borderRadius: '50%',\n      display: 'flex',\n      alignItems: 'center',\n      justifyContent: 'center',\n      fontWeight: 'bold',\n      border: '2px solid white',\n      boxSizing: 'border-box',\n      zIndex: 1\n    }\n  }, notificationCount > 99 ? '99+' : notificationCount)))), showCart && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {\n    iconProps: {\n      iconName: 'ShoppingCart'\n    },\n    styles: iconButtonStyles(iconColor)\n  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {\n    iconProps: {\n      iconName: 'Contact'\n    },\n    styles: iconButtonStyles(iconColor)\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Persona, Object.assign({}, personaProps))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PowerHeader/HeaderApp.tsx?\n}");

/***/ },

/***/ "./PowerHeader/index.ts"
/*!******************************!*\
  !*** ./PowerHeader/index.ts ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   PowerHeader: () => (/* binding */ PowerHeader)\n/* harmony export */ });\n/* harmony import */ var _HeaderApp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HeaderApp */ \"./PowerHeader/HeaderApp.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass PowerHeader {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n  }\n  /**\n   * Called when any value in the property bag has changed.\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j;\n    var props = {\n      username: (_a = context.parameters.Username.raw) !== null && _a !== void 0 ? _a : \"User\",\n      designation: (_b = context.parameters.Designation.raw) !== null && _b !== void 0 ? _b : \"Designation\",\n      profileImageUrl: (_c = context.parameters.ProfileImageUrl.raw) !== null && _c !== void 0 ? _c : undefined,\n      userRole: (_d = context.parameters.UserRole.raw) !== null && _d !== void 0 ? _d : \"Employee\",\n      notificationCount: (_e = context.parameters.NotificationCount.raw) !== null && _e !== void 0 ? _e : 0,\n      headerBackground: (_f = context.parameters.HeaderBackground.raw) !== null && _f !== void 0 ? _f : undefined,\n      iconColor: (_g = context.parameters.IconColor.raw) !== null && _g !== void 0 ? _g : undefined,\n      roleBackgroundColor: (_h = context.parameters.RoleBackgroundColor.raw) !== null && _h !== void 0 ? _h : undefined,\n      roleTextColor: (_j = context.parameters.RoleTextColor.raw) !== null && _j !== void 0 ? _j : undefined,\n      showCart: context.parameters.ShowCart.raw,\n      showNotification: context.parameters.ShowNotification.raw,\n      width: context.mode.allocatedWidth\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_HeaderApp__WEBPACK_IMPORTED_MODULE_0__.HeaderApp, props);\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PowerHeader/index.ts?\n}");

/***/ },

/***/ "@fluentui/react"
/*!**************************************!*\
  !*** external "FluentUIReactv81211" ***!
  \**************************************/
(module) {

module.exports = FluentUIReactv81211;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./PowerHeader/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('HeaderNamespace.PowerHeader', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerHeader);
} else {
	var HeaderNamespace = HeaderNamespace || {};
	HeaderNamespace.PowerHeader = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PowerHeader;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}