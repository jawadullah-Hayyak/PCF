/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./IframeGalleryControl/index.ts"
/*!***************************************!*\
  !*** ./IframeGalleryControl/index.ts ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   IframeGalleryControl: () => (/* binding */ IframeGalleryControl)\n/* harmony export */ });\nclass IframeGalleryControl {\n  constructor() {\n    this.selectedRecordsJson = \"\";\n    this.actionType = \"\";\n    this.tabsConfig = null;\n    // ================= IFRAME → PCF EVENTS =================\n    this.handleIframeEvents = event => {\n      var _a;\n      if (!((_a = event.data) === null || _a === void 0 ? void 0 : _a.type)) return;\n      var {\n        type,\n        payload\n      } = event.data;\n      switch (type) {\n        case \"SELECTION_CHANGE\":\n          this.actionType = \"SELECTION_CHANGE\";\n          this.selectedRecordsJson = JSON.stringify(payload !== null && payload !== void 0 ? payload : []);\n          break;\n        case \"EDIT\":\n          this.actionType = \"EDIT\";\n          this.selectedRecordsJson = JSON.stringify(payload ? [payload] : []);\n          break;\n        case \"DELETE\":\n        case \"BULK_DELETE\":\n          this.actionType = type;\n          this.selectedRecordsJson = JSON.stringify(payload !== null && payload !== void 0 ? payload : []);\n          break;\n        case \"COPY\":\n          this.actionType = \"COPY\";\n          this.selectedRecordsJson = JSON.stringify([{\n            requestId: payload\n          }]);\n          break;\n        case \"VIEW\":\n          this.actionType = \"VIEW\";\n          this.selectedRecordsJson = JSON.stringify(payload ? [payload] : []);\n          break;\n        case \"APPROVE\":\n          this.actionType = \"APPROVE\";\n          this.selectedRecordsJson = JSON.stringify([payload]);\n          break;\n        case \"REJECT\":\n          this.actionType = \"REJECT\";\n          this.selectedRecordsJson = JSON.stringify([payload]);\n          break;\n        default:\n          return;\n      }\n      this.notifyOutputChanged();\n    };\n  }\n  // ================= INIT =================\n  init(context, notifyOutputChanged, state, container) {\n    var _a, _b;\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.iframe = document.createElement(\"iframe\");\n    this.iframe.style.width = \"100%\";\n    this.iframe.style.height = \"100%\";\n    this.iframe.style.border = \"none\";\n    this.iframe.src = (_b = (_a = context.parameters.webResourceUrl) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"\";\n    container.appendChild(this.iframe);\n    this.iframe.onload = () => this.sendDataToIframe();\n    window.removeEventListener(\"message\", this.handleIframeEvents);\n    window.addEventListener(\"message\", this.handleIframeEvents);\n  }\n  // ================= SEND DATA TO IFRAME =================\n  sendDataToIframe() {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;\n    // ensure iframe ready\n    if (!this.iframe || !this.iframe.contentWindow) return;\n    if (!this.PageSize) {\n      return; // wait for updateView\n    }\n    var columns = [];\n    var data = [];\n    var statusFilters = [];\n    var uiConfig = {};\n    try {\n      uiConfig = JSON.parse((_b = (_a = this.context.parameters.uiConfig) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"{}\");\n    } catch (_m) {\n      uiConfig = {};\n    }\n    try {\n      columns = JSON.parse((_d = (_c = this.context.parameters.columnsJson) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : \"[]\");\n    } catch (e) {\n      console.warn(\"Failed to parse columnsJson\", e);\n      columns = [];\n    }\n    try {\n      data = JSON.parse((_f = (_e = this.context.parameters.dataJson) === null || _e === void 0 ? void 0 : _e.raw) !== null && _f !== void 0 ? _f : \"[]\");\n    } catch (e) {\n      console.warn(\"Failed to parse dataJson\", e);\n      data = [];\n    }\n    try {\n      var raw = JSON.parse((_h = (_g = this.context.parameters.StatusFilterTypes) === null || _g === void 0 ? void 0 : _g.raw) !== null && _h !== void 0 ? _h : \"[]\");\n      if (Array.isArray(raw)) {\n        statusFilters = raw.map(x => x.Result).filter(v => typeof v === \"string\");\n      }\n    } catch (e) {\n      console.warn(\"Failed to parse StatusFilterTypes\", e);\n    }\n    // detect date columns\n    var dateCols = (columns || []).filter(c => !!c && (c.type === \"date\" || typeof c.format === \"string\"));\n    // coerce user timezone offset (minutes) from context.userSettings\n    var uS = this.context && this.context.userSettings || {};\n    var rawOffset = (_l = (_k = (_j = uS.timeZoneOffset) !== null && _j !== void 0 ? _j : uS.timeZoneOffsetMinutes) !== null && _k !== void 0 ? _k : uS.timeZoneBias) !== null && _l !== void 0 ? _l : null;\n    var userTzOffsetMinutes = rawOffset != null ? Number(rawOffset) : NaN;\n    var hasUserOffset = Number.isFinite(userTzOffsetMinutes);\n    // helper that converts UTC epoch (ms) -> user local epoch ms by adding offset minutes\n    function msToUserMs(parsedMs) {\n      if (hasUserOffset) {\n        return parsedMs + userTzOffsetMinutes * 60000;\n      }\n      return parsedMs;\n    }\n    function formatDateValue(value, format) {\n      if (value == null || value === \"\") return \"\";\n      var parsedMs = null;\n      if (value instanceof Date) parsedMs = value.getTime();else if (typeof value === \"number\") parsedMs = value;else if (typeof value === \"string\") {\n        var p = Date.parse(value);\n        if (!isNaN(p)) parsedMs = p;else return String(value);\n      } else return String(value);\n      // IMPORTANT: keep case of format to differentiate 'MM' (month) vs 'mm' (minutes)\n      var fmt = format !== null && format !== void 0 ? format : \"dd/MM/yyyy\";\n      // Decide whether a time portion is explicitly requested.\n      // Only treat minutes ('mm') as minutes if an hour token is present too.\n      var hasHourToken = fmt.includes(\"h\") || fmt.includes(\"hh\") || fmt.includes(\"H\") || fmt.includes(\"HH\");\n      var hasAmPmToken = fmt.includes(\"tt\") || /am\\/pm/i.test(fmt) || /a\\/p/i.test(fmt);\n      var hasSecondToken = /s{1,2}/.test(fmt);\n      // minute token detection - lowercase 'mm' indicates minutes; uppercase 'MM' is month.\n      var hasMinuteToken = fmt.includes(\"mm\") && !fmt.includes(\"MM\");\n      var wantsTime = hasHourToken || hasAmPmToken || hasSecondToken || hasMinuteToken && hasHourToken;\n      if (hasUserOffset) {\n        // apply Dataverse user offset then use UTC getters\n        var userMs = msToUserMs(parsedMs);\n        var d = new Date(userMs);\n        var day = String(d.getUTCDate()).padStart(2, \"0\");\n        var month = String(d.getUTCMonth() + 1).padStart(2, \"0\");\n        var year = d.getUTCFullYear();\n        if (!wantsTime) {\n          return \"\".concat(day, \"/\").concat(month, \"/\").concat(year);\n        }\n        var h24 = d.getUTCHours();\n        var mins = String(d.getUTCMinutes()).padStart(2, \"0\");\n        var secs = String(d.getUTCSeconds()).padStart(2, \"0\");\n        if (hasAmPmToken) {\n          var period = h24 >= 12 ? \"PM\" : \"AM\";\n          var h12 = h24 % 12;\n          if (h12 === 0) h12 = 12;\n          var hh = String(h12).padStart(2, \"0\");\n          return hasSecondToken ? \"\".concat(day, \"/\").concat(month, \"/\").concat(year, \" \").concat(hh, \":\").concat(mins, \":\").concat(secs, \" \").concat(period) : \"\".concat(day, \"/\").concat(month, \"/\").concat(year, \" \").concat(hh, \":\").concat(mins, \" \").concat(period);\n        } else {\n          var _hh = String(h24).padStart(2, \"0\");\n          return hasSecondToken ? \"\".concat(day, \"/\").concat(month, \"/\").concat(year, \" \").concat(_hh, \":\").concat(mins, \":\").concat(secs) : \"\".concat(day, \"/\").concat(month, \"/\").concat(year, \" \").concat(_hh, \":\").concat(mins);\n        }\n      } else {\n        // fallback: browser local time\n        var _d2 = new Date(parsedMs);\n        var _day = String(_d2.getDate()).padStart(2, \"0\");\n        var _month = String(_d2.getMonth() + 1).padStart(2, \"0\");\n        var _year = _d2.getFullYear();\n        if (!wantsTime) {\n          return \"\".concat(_day, \"/\").concat(_month, \"/\").concat(_year);\n        }\n        var _h2 = _d2.getHours();\n        var _mins = String(_d2.getMinutes()).padStart(2, \"0\");\n        var _secs = String(_d2.getSeconds()).padStart(2, \"0\");\n        if (hasAmPmToken) {\n          var _period = _h2 >= 12 ? \"PM\" : \"AM\";\n          var _h3 = _h2 % 12;\n          if (_h3 === 0) _h3 = 12;\n          var _hh2 = String(_h3).padStart(2, \"0\");\n          return hasSecondToken ? \"\".concat(_day, \"/\").concat(_month, \"/\").concat(_year, \" \").concat(_hh2, \":\").concat(_mins, \":\").concat(_secs, \" \").concat(_period) : \"\".concat(_day, \"/\").concat(_month, \"/\").concat(_year, \" \").concat(_hh2, \":\").concat(_mins, \" \").concat(_period);\n        } else {\n          var _hh3 = String(_h2).padStart(2, \"0\");\n          return hasSecondToken ? \"\".concat(_day, \"/\").concat(_month, \"/\").concat(_year, \" \").concat(_hh3, \":\").concat(_mins, \":\").concat(_secs) : \"\".concat(_day, \"/\").concat(_month, \"/\").concat(_year, \" \").concat(_hh3, \":\").concat(_mins);\n        }\n      }\n    }\n    var dataArray = Array.isArray(data) ? data : [];\n    var formattedData = dataArray.map(row => {\n      var copy = Object.assign({}, row);\n      for (var col of dateCols) {\n        var key = col.key;\n        var format = col.format;\n        if (Object.prototype.hasOwnProperty.call(copy, key)) {\n          try {\n            var rawVal = copy[key];\n            var formatted = formatDateValue(rawVal, format);\n            // preserve raw if you want: copy[`${key}Raw`] = copy[key];\n            copy[key] = formatted;\n          } catch (_a) {\n            copy[key] = copy[key] != null ? String(copy[key]) : \"\";\n          }\n        } else {\n          copy[key] = \"\";\n        }\n      }\n      return copy;\n    });\n    var targetOrigin = this.iframe.src ? new URL(this.iframe.src).origin : \"*\";\n    this.iframe.contentWindow.postMessage({\n      type: \"INIT_GALLERY\",\n      columns,\n      data: formattedData,\n      pageSize: this.PageSize,\n      statusFilters,\n      tabsConfig: this.tabsConfig,\n      uiConfig\n    }, targetOrigin);\n  }\n  // ================= UPDATE VIEW =================\n  updateView(context) {\n    this.context = context;\n    var canvasPageSizeRaw = context.parameters.PageSize.raw;\n    var tabsConfigRaw = context.parameters.TabsConfig.raw;\n    try {\n      this.tabsConfig = tabsConfigRaw ? JSON.parse(tabsConfigRaw) : null;\n    } catch (_a) {\n      this.tabsConfig = null;\n    }\n    // Validation only — no UX defaults\n    this.PageSize = typeof canvasPageSizeRaw === \"number\" && canvasPageSizeRaw > 0 ? canvasPageSizeRaw : 1;\n    this.sendDataToIframe();\n  }\n  // ================= OUTPUTS =================\n  getOutputs() {\n    return {\n      selectedRecordJson: this.selectedRecordsJson,\n      actionType: this.actionType\n    };\n  }\n  // ================= DESTROY =================\n  destroy() {\n    window.removeEventListener(\"message\", this.handleIframeEvents);\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./IframeGalleryControl/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./IframeGalleryControl/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('IframeGallery.IframeGalleryControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IframeGalleryControl);
} else {
	var IframeGallery = IframeGallery || {};
	IframeGallery.IframeGalleryControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IframeGalleryControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}