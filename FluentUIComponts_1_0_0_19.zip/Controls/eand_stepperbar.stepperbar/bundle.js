/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./stepperbar/Stepper.tsx"
/*!********************************!*\
  !*** ./stepperbar/Stepper.tsx ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Stepper: () => (/* binding */ Stepper)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar Stepper = _ref => {\n  var {\n    steps,\n    onStepClick,\n    isEditable,\n    selectedId\n  } = _ref;\n  var [isMobile, setIsMobile] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    var checkMobile = () => {\n      setIsMobile(window.innerWidth <= 768);\n    };\n    checkMobile();\n    window.addEventListener('resize', checkMobile);\n    return () => window.removeEventListener('resize', checkMobile);\n  }, []);\n  var getStepState = status => {\n    if (status === 'Completed') {\n      return 'completed';\n    }\n    if (status === 'Active') {\n      return 'active';\n    }\n    return 'inactive';\n  };\n  var renderStepIcon = state => {\n    if (state === 'completed') {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n        width: \"24\",\n        height: \"24\",\n        viewBox: \"0 0 24 24\",\n        fill: \"none\",\n        xmlns: \"http://www.w3.org/2000/svg\"\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"mask\", {\n        id: \"mask0_8516_9993\",\n        style: {\n          maskType: 'alpha'\n        },\n        maskUnits: \"userSpaceOnUse\",\n        x: \"0\",\n        y: \"0\",\n        width: \"24\",\n        height: \"24\"\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"rect\", {\n        width: \"24\",\n        height: \"24\",\n        fill: \"#D9D9D9\"\n      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"g\", {\n        mask: \"url(#mask0_8516_9993)\"\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n        d: \"M10.5808 16.2538L17.3038 9.53075L16.25 8.47693L10.5808 14.1462L7.73075 11.2962L6.67693 12.35L10.5808 16.2538ZM12.0016 21.5C10.6877 21.5 9.45268 21.2506 8.29655 20.752C7.1404 20.2533 6.13472 19.5765 5.2795 18.7217C4.42427 17.8669 3.74721 16.8616 3.24833 15.706C2.74944 14.5504 2.5 13.3156 2.5 12.0017C2.5 10.6877 2.74933 9.45268 3.248 8.29655C3.74667 7.1404 4.42342 6.13472 5.27825 5.2795C6.1331 4.42427 7.13834 3.74721 8.29398 3.24833C9.44959 2.74944 10.6844 2.5 11.9983 2.5C13.3122 2.5 14.5473 2.74933 15.7034 3.248C16.8596 3.74667 17.8652 4.42342 18.7205 5.27825C19.5757 6.1331 20.2527 7.13834 20.7516 8.29398C21.2505 9.44959 21.5 10.6844 21.5 11.9983C21.5 13.3122 21.2506 14.5473 20.752 15.7034C20.2533 16.8596 19.5765 17.8652 18.7217 18.7205C17.8669 19.5757 16.8616 20.2527 15.706 20.7516C14.5504 21.2505 13.3156 21.5 12.0016 21.5Z\",\n        fill: \"#0B7C54\"\n      })));\n    } else if (state === 'active') {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n        width: \"24\",\n        height: \"24\",\n        viewBox: \"0 0 24 24\",\n        fill: \"none\",\n        xmlns: \"http://www.w3.org/2000/svg\"\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"circle\", {\n        cx: \"12\",\n        cy: \"12\",\n        r: \"11\",\n        stroke: \"#E53935\",\n        strokeWidth: \"2\",\n        fill: \"white\"\n      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"circle\", {\n        cx: \"12\",\n        cy: \"12\",\n        r: \"6\",\n        fill: \"#E53935\"\n      }));\n    } else {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n        width: \"24\",\n        height: \"24\",\n        viewBox: \"0 0 24 24\",\n        fill: \"none\",\n        xmlns: \"http://www.w3.org/2000/svg\"\n      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"circle\", {\n        cx: \"12\",\n        cy: \"12\",\n        r: \"11\",\n        stroke: \"#D1D5DB\",\n        strokeWidth: \"2\",\n        fill: \"white\"\n      }));\n    }\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: isMobile ? styles.containerMobile : styles.container\n  }, steps.map((step, index) => {\n    var state = getStepState(step.status);\n    var isLast = index === steps.length - 1;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      key: step.id,\n      style: Object.assign(Object.assign({}, isMobile ? styles.stepWrapperMobile : styles.stepWrapper), {\n        cursor: isEditable ? 'pointer' : 'default'\n      }),\n      onClick: () => isEditable && (onStepClick === null || onStepClick === void 0 ? void 0 : onStepClick(step.id))\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: isMobile ? styles.iconLineRowMobile : styles.iconLineRow\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: styles.iconWrapper\n    }, renderStepIcon(state)), !isLast && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: Object.assign(Object.assign({}, isMobile ? styles.lineMobile : styles.line), {\n        borderColor: state === 'completed' ? '#0B7C54' : '#D1D5DB'\n      })\n    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: isMobile ? styles.stepContentMobile : styles.stepContent\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: Object.assign(Object.assign({}, styles.stepLabel), {\n        color: state === 'completed' ? '#0B7C54' : state === 'active' ? '#E53935' : '#9CA3AF'\n      })\n    }, step.label), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: Object.assign(Object.assign({}, styles.stepTitle), {\n        color: state === 'active' ? '#1F2937' : '#6B7280',\n        fontWeight: state === 'active' ? 700 : 400,\n        lineHeight: state === 'active' ? '20px' : '20px'\n      })\n    }, step.title)));\n  }));\n};\nvar styles = {\n  container: {\n    display: 'flex',\n    alignItems: 'flex-start',\n    width: '100%',\n    padding: '20px',\n    backgroundColor: '#FFFFFF',\n    border: 'none'\n  },\n  stepWrapper: {\n    flex: 1,\n    display: 'flex',\n    flexDirection: 'column',\n    alignItems: 'flex-start',\n    gap: '8px'\n  },\n  iconLineRow: {\n    display: 'flex',\n    flexDirection: 'row',\n    justifyContent: 'flex-start',\n    alignItems: 'center',\n    padding: '0px',\n    gap: '11px',\n    width: '95%',\n    height: '24px',\n    opacity: 1\n  },\n  containerMobile: {\n    display: 'flex',\n    flexDirection: 'column',\n    alignItems: 'flex-start',\n    width: '100%',\n    padding: '20px',\n    backgroundColor: '#FFFFFF',\n    border: 'none'\n  },\n  stepWrapperMobile: {\n    width: '100%',\n    display: 'flex',\n    flexDirection: 'row',\n    alignItems: 'center',\n    marginBottom: '16px',\n    gap: '8px'\n  },\n  iconLineRowMobile: {\n    display: 'flex',\n    flexDirection: 'column',\n    alignItems: 'center',\n    marginRight: '12px',\n    gap: '4px'\n  },\n  lineMobile: {\n    width: '2px',\n    height: '30px',\n    minHeight: '30px'\n  },\n  stepContentMobile: {\n    display: 'flex',\n    flexDirection: 'column',\n    gap: '2px',\n    opacity: 1,\n    textAlign: 'left',\n    flex: 1\n  },\n  iconWrapper: {\n    flexShrink: 0,\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center',\n    width: '24px',\n    height: '24px'\n  },\n  line: {\n    flex: 1,\n    height: '0px',\n    borderTop: '1px solid',\n    transform: 'rotate(180deg)',\n    opacity: 1\n  },\n  stepContent: {\n    display: 'flex',\n    flexDirection: 'column',\n    alignItems: 'flex-start',\n    padding: '0px',\n    gap: '2px',\n    width: '100%',\n    height: '37px',\n    opacity: 1,\n    textAlign: 'left'\n  },\n  stepLabel: {\n    fontFamily: 'Roboto',\n    fontWeight: 400,\n    fontSize: '10px',\n    lineHeight: '12px',\n    letterSpacing: '0.0025em',\n    textAlign: 'left'\n  },\n  stepTitle: {\n    fontFamily: 'Arial',\n    fontWeight: 400,\n    fontSize: '14px',\n    //lineHeight: '20px',\n    letterSpacing: '0%',\n    verticalAlign: 'middle',\n    textAlign: 'left',\n    display: 'flex',\n    alignItems: 'center'\n  }\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./stepperbar/Stepper.tsx?\n}");

/***/ },

/***/ "./stepperbar/index.ts"
/*!*****************************!*\
  !*** ./stepperbar/index.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   stepperbar: () => (/* binding */ stepperbar)\n/* harmony export */ });\n/* harmony import */ var _Stepper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Stepper */ \"./stepperbar/Stepper.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass stepperbar {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.selectedId = \"\";\n    this.lastStepsJson = \"\";\n    this.lastSelectedTab = null;\n    this.isEditable = true;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a;\n    // Parse steps from JSON string\n    var steps = [];\n    var stepsJson = (_a = context.parameters.steps.raw) !== null && _a !== void 0 ? _a : '[]';\n    var selectedTab = context.parameters.selectedTab.raw;\n    this.isEditable = context.parameters.IsEditable.raw;\n    try {\n      steps = JSON.parse(stepsJson);\n      var oldSelectedId = this.selectedId;\n      // Priority 1: selectedTab input\n      if (selectedTab !== this.lastSelectedTab) {\n        this.lastSelectedTab = selectedTab;\n        this.selectedId = selectedTab !== null && selectedTab !== void 0 ? selectedTab : \"\";\n      }\n      // Priority 2: Default to 'Active' step if no selectedTab is provided AND it's the first time we have steps (or selectedId is empty)\n      else if (this.selectedId === \"\" && stepsJson !== this.lastStepsJson && (selectedTab === \"\" || selectedTab === null)) {\n        this.lastStepsJson = stepsJson;\n        var activeStep = steps.find(s => s.status === 'Active');\n        if (activeStep) {\n          this.selectedId = activeStep.id;\n        }\n      } else if (stepsJson !== this.lastStepsJson) {\n        this.lastStepsJson = stepsJson;\n      }\n      // Notify framework if selection changed programmatically\n      if (this.selectedId !== oldSelectedId) {\n        this.notifyOutputChanged();\n      }\n    } catch (error) {\n      console.error('Error parsing steps:', error);\n      steps = [];\n    }\n    var props = {\n      steps,\n      isEditable: this.isEditable,\n      selectedId: this.selectedId,\n      onStepClick: id => {\n        this.selectedId = id;\n        this.notifyOutputChanged();\n      }\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_Stepper__WEBPACK_IMPORTED_MODULE_0__.Stepper, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    // Use a more robust way to check if we are in editable mode\n    // Since we don't have direct access to context here easily without storing it,\n    // we'll rely on the property being passed to updateView.\n    // Actually, it's safer to just check this.selectedId and the parameter.\n    return {\n      SelectedId: this.isEditable ? this.selectedId : \"\"\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./stepperbar/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./stepperbar/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('stepperbar.stepperbar', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.stepperbar);
} else {
	var stepperbar = stepperbar || {};
	stepperbar.stepperbar = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.stepperbar;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}