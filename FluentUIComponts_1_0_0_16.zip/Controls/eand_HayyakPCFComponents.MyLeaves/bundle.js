/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./MyLeaves/LeaveItem.tsx"
/*!********************************!*\
  !*** ./MyLeaves/LeaveItem.tsx ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LeaveItem: () => (/* binding */ LeaveItem)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar LeaveItem = props => {\n  var {\n    name,\n    used,\n    total\n  } = props;\n  // Calculate percentage\n  var percentage = total > 0 ? Math.min(100, Math.max(0, used / total * 100)) : 0;\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"leaf-item\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"leaf-row-top\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"leaf-name\"\n  }, name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"leaf-status\"\n  }, used, \"/\", total, \" Left\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-progress-container\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-progress-fill\",\n    style: {\n      width: \"\".concat(percentage, \"%\")\n    }\n  })));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MyLeaves/LeaveItem.tsx?\n}");

/***/ },

/***/ "./MyLeaves/MyLeaves.tsx"
/*!*******************************!*\
  !*** ./MyLeaves/MyLeaves.tsx ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   MyLeaves: () => (/* binding */ MyLeaves)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _LeaveItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LeaveItem */ \"./MyLeaves/LeaveItem.tsx\");\n\n\nvar MyLeaves = props => {\n  var {\n    title,\n    items,\n    height,\n    onViewAllClick\n  } = props;\n  console.log(\"[MyLeaves] Render - received height: \".concat(height));\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-container\",\n    style: {\n      height: height\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-header\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-title\"\n  }, title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-view-all\",\n    onClick: onViewAllClick\n  }, \"VIEW ALL\", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    width: \"6\",\n    height: \"10\",\n    viewBox: \"0 0 6 10\",\n    fill: \"none\",\n    xmlns: \"http://www.w3.org/2000/svg\",\n    style: {\n      marginLeft: '8px'\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M1 9L5 5L1 1\",\n    stroke: \"#E00800\",\n    strokeWidth: \"1.5\",\n    strokeLinecap: \"round\",\n    strokeLinejoin: \"round\"\n  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"my-leaves-list\"\n  }, items.map((item, index) => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_LeaveItem__WEBPACK_IMPORTED_MODULE_1__.LeaveItem, {\n    key: index,\n    name: item.name,\n    used: item.used,\n    total: item.total\n  })))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MyLeaves/MyLeaves.tsx?\n}");

/***/ },

/***/ "./MyLeaves/index.ts"
/*!***************************!*\
  !*** ./MyLeaves/index.ts ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   MyLeaves: () => (/* binding */ MyLeaves)\n/* harmony export */ });\n/* harmony import */ var _MyLeaves__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MyLeaves */ \"./MyLeaves/MyLeaves.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass MyLeaves {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._viewAllClickCount = 0;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a;\n    this._context = context;\n    console.log(\"MyLeaves allocatedHeight:\", context.mode.allocatedHeight);\n    var title = (_a = context.parameters.title.raw) !== null && _a !== void 0 ? _a : \"My Leaves\";\n    var dataset = context.parameters.leaveData;\n    // Map dataset records\n    var items = dataset.sortedRecordIds.map(id => {\n      var record = dataset.records[id];\n      return {\n        name: record.getFormattedValue(\"leaveName\"),\n        used: record.getValue(\"leaveUsed\") || 0,\n        total: record.getValue(\"leaveTotal\") || 0\n      };\n    });\n    var allocatedHeight = context.mode.allocatedHeight;\n    var height = allocatedHeight !== -1 ? \"\".concat(allocatedHeight, \"px\") : \"100%\";\n    console.log(\"[MyLeaves] updateView - allocatedHeight: \".concat(allocatedHeight, \", passing height: \").concat(height));\n    var props = {\n      title,\n      items,\n      height: height,\n      onViewAllClick: this.onViewAllClick.bind(this)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_MyLeaves__WEBPACK_IMPORTED_MODULE_0__.MyLeaves, props);\n  }\n  onViewAllClick() {\n    // Increment the trigger to notify the host\n    this._viewAllClickCount++;\n    console.log(\"[MyLeaves] onViewAllClick in index.ts - Count: \".concat(this._viewAllClickCount, \" - Calling notifyOutputChanged()\"));\n    this.notifyOutputChanged();\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      viewAllClickTrigger: this._viewAllClickCount\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MyLeaves/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./MyLeaves/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('HayyakPCFComponents.MyLeaves', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MyLeaves);
} else {
	var HayyakPCFComponents = HayyakPCFComponents || {};
	HayyakPCFComponents.MyLeaves = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MyLeaves;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}