/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./BoxFilterControl/FilterApp.tsx"
/*!****************************************!*\
  !*** ./BoxFilterControl/FilterApp.tsx ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FilterApp: () => (/* binding */ FilterApp)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar HistoryIconMarkup = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n  width: \"20\",\n  height: \"20\",\n  viewBox: \"0 0 24 24\",\n  fill: \"none\",\n  stroke: \"currentColor\",\n  strokeWidth: \"2\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"rect\", {\n  x: \"3\",\n  y: \"4\",\n  width: \"18\",\n  height: \"18\",\n  rx: \"2\",\n  ry: \"2\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"line\", {\n  x1: \"16\",\n  y1: \"2\",\n  x2: \"16\",\n  y2: \"6\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"line\", {\n  x1: \"8\",\n  y1: \"2\",\n  x2: \"8\",\n  y2: \"6\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"line\", {\n  x1: \"3\",\n  y1: \"10\",\n  x2: \"21\",\n  y2: \"10\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M9 16l2 2 4-4\"\n}));\nvar FilterApp = _ref => {\n  var {\n    inputJSON,\n    onHistoryClick,\n    boxMaxWidth,\n    boxHeight,\n    allocatedHeight\n  } = _ref;\n  var [boxes, setBoxes] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var isSmallHeight = allocatedHeight !== undefined && allocatedHeight > 0 && allocatedHeight < 200;\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    try {\n      var parsedData = JSON.parse(inputJSON);\n      if (Array.isArray(parsedData)) {\n        setBoxes(parsedData);\n      }\n    } catch (error) {\n      console.error(\"Error parsing input JSON\", error);\n    }\n  }, [inputJSON]);\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"hayyak-filter-container \".concat(isSmallHeight ? 'small-height' : '')\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"hayyak-filter-header\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h2\", {\n    className: \"hayyak-filter-title\"\n  }, \"Filters\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: \"hayyak-history-button\",\n    onClick: onHistoryClick\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"hayyak-history-icon\"\n  }, HistoryIconMarkup), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, \"Requests History\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"hayyak-history-arrow\"\n  }, \">\"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"hayyak-boxes-grid\"\n  }, boxes.map(box => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    key: box.id,\n    className: \"hayyak-filter-box\",\n    style: {\n      backgroundColor: box.boxColor,\n      maxWidth: boxMaxWidth ? \"\".concat(boxMaxWidth, \"px\") : '100%',\n      height: boxHeight ? \"\".concat(boxHeight, \"px\") : isSmallHeight ? '100%' : 'auto',\n      minHeight: boxHeight ? \"\".concat(boxHeight, \"px\") : undefined,\n      flex: boxMaxWidth ? \"0 1 \".concat(boxMaxWidth, \"px\") : '1 1 0px'\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"hayyak-box-content\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"hayyak-box-count\"\n  }, box.count), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n    className: \"hayyak-box-label\"\n  }, box.title)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"hayyak-box-icon\",\n    dangerouslySetInnerHTML: {\n      __html: box.svgIcon\n    },\n    style: {\n      color: box.iconBgColor\n    }\n  }))))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./BoxFilterControl/FilterApp.tsx?\n}");

/***/ },

/***/ "./BoxFilterControl/index.ts"
/*!***********************************!*\
  !*** ./BoxFilterControl/index.ts ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   BoxFilterControl: () => (/* binding */ BoxFilterControl)\n/* harmony export */ });\n/* harmony import */ var _FilterApp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FilterApp */ \"./BoxFilterControl/FilterApp.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass BoxFilterControl {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._triggerHistoryRedirect = 0;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed.\n   */\n  updateView(context) {\n    var _a, _b;\n    var rawInput = context.parameters.InputJSON.raw;\n    var inputStr = rawInput ? rawInput : \"[]\";\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_FilterApp__WEBPACK_IMPORTED_MODULE_0__.FilterApp, {\n      inputJSON: inputStr,\n      onHistoryClick: this.onHistoryClick.bind(this),\n      boxMaxWidth: ((_a = context.parameters.BoxMaxWidth) === null || _a === void 0 ? void 0 : _a.raw) || undefined,\n      boxHeight: ((_b = context.parameters.BoxHeight) === null || _b === void 0 ? void 0 : _b.raw) || undefined,\n      allocatedHeight: context.mode.allocatedHeight\n    });\n  }\n  onHistoryClick() {\n    this._triggerHistoryRedirect++;\n    this.notifyOutputChanged();\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   */\n  getOutputs() {\n    return {\n      TriggerHistoryRedirect: this._triggerHistoryRedirect\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./BoxFilterControl/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./BoxFilterControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AsimFilter.BoxFilterControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BoxFilterControl);
} else {
	var AsimFilter = AsimFilter || {};
	AsimFilter.BoxFilterControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BoxFilterControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}