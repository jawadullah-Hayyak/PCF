/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./buttonPCF/ButtonControl.tsx"
/*!*************************************!*\
  !*** ./buttonPCF/ButtonControl.tsx ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ButtonControl: () => (/* binding */ ButtonControl)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.makeStyles)({\n  root: {\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center',\n    padding: '16px 24px',\n    gap: '8px',\n    boxSizing: 'border-box',\n    cursor: 'pointer',\n    border: 'none',\n    transition: 'background-color 0.2s ease'\n  },\n  icon: {\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center',\n    width: '20px',\n    height: '20px',\n    flexShrink: 0\n  }\n});\nvar ButtonControl = props => {\n  var _a, _b;\n  var {\n    label,\n    backgroundColor,\n    textColor,\n    fontFamily,\n    iconSvg,\n    width,\n    height,\n    borderRadius,\n    fontSize,\n    hoverBackgroundColor,\n    fontWeight,\n    onClick\n  } = props;\n  var styles = useStyles();\n  var [isHovered, setIsHovered] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var buttonStyle = {\n    backgroundColor: isHovered ? (_a = hoverBackgroundColor !== null && hoverBackgroundColor !== void 0 ? hoverBackgroundColor : backgroundColor) !== null && _a !== void 0 ? _a : '#FF0000' : backgroundColor !== null && backgroundColor !== void 0 ? backgroundColor : '#FF0000',\n    color: textColor !== null && textColor !== void 0 ? textColor : '#ffffff',\n    fontFamily: fontFamily !== null && fontFamily !== void 0 ? fontFamily : 'Segoe UI, sans-serif',\n    borderRadius: borderRadius ? \"\".concat(borderRadius, \"px\") : '6px',\n    fontSize: fontSize ? \"\".concat(fontSize, \"px\") : '16px',\n    fontWeight: (_b = fontWeight) !== null && _b !== void 0 ? _b : 'bold',\n    width: width ? \"\".concat(width, \"px\") : 'fit-content',\n    height: height ? \"\".concat(height, \"px\") : '50px',\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center',\n    gap: '6px',\n    padding: '4px 4px',\n    textTransform: 'uppercase',\n    // Based on screenshot\n    letterSpacing: '1px'\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    style: buttonStyle,\n    onMouseEnter: () => setIsHovered(true),\n    onMouseLeave: () => setIsHovered(false),\n    onClick: onClick,\n    className: styles.root\n  }, iconSvg && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.icon,\n    dangerouslySetInnerHTML: {\n      __html: iconSvg\n    }\n  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, label));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./buttonPCF/ButtonControl.tsx?\n}");

/***/ },

/***/ "./buttonPCF/index.ts"
/*!****************************!*\
  !*** ./buttonPCF/index.ts ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   buttonPCF: () => (/* binding */ buttonPCF)\n/* harmony export */ });\n/* harmony import */ var _ButtonControl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonControl */ \"./buttonPCF/ButtonControl.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass buttonPCF {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._triggerSignal = 0;\n    this.handleOnClick = () => {\n      this._triggerSignal++;\n      this.notifyOutputChanged();\n    };\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;\n    var props = {\n      label: (_a = context.parameters.Label.raw) !== null && _a !== void 0 ? _a : \"NEW REQUEST\",\n      backgroundColor: (_b = context.parameters.BackgroundColor.raw) !== null && _b !== void 0 ? _b : undefined,\n      textColor: (_c = context.parameters.TextColor.raw) !== null && _c !== void 0 ? _c : undefined,\n      fontFamily: (_d = context.parameters.FontFamily.raw) !== null && _d !== void 0 ? _d : undefined,\n      iconSvg: (_e = context.parameters.IconSvg.raw) !== null && _e !== void 0 ? _e : undefined,\n      width: (_f = context.parameters.Width.raw) !== null && _f !== void 0 ? _f : undefined,\n      height: (_g = context.parameters.Height.raw) !== null && _g !== void 0 ? _g : undefined,\n      borderRadius: (_h = context.parameters.BorderRadius.raw) !== null && _h !== void 0 ? _h : undefined,\n      fontSize: (_j = context.parameters.FontSize.raw) !== null && _j !== void 0 ? _j : undefined,\n      hoverBackgroundColor: (_k = context.parameters.HoverBackgroundColor.raw) !== null && _k !== void 0 ? _k : undefined,\n      fontWeight: (_l = context.parameters.FontWeight.raw) !== null && _l !== void 0 ? _l : undefined,\n      onClick: this.handleOnClick\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_ButtonControl__WEBPACK_IMPORTED_MODULE_0__.ButtonControl, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      Trigger: this._triggerSignal\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./buttonPCF/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./buttonPCF/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('buttonPCF.buttonPCF', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.buttonPCF);
} else {
	var buttonPCF = buttonPCF || {};
	buttonPCF.buttonPCF = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.buttonPCF;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}