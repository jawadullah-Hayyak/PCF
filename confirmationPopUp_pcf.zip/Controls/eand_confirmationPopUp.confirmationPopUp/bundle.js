/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./confirmationPopUp/ConfirmationPopup.tsx"
/*!*************************************************!*\
  !*** ./confirmationPopUp/ConfirmationPopup.tsx ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ConfirmationPopup: () => (/* binding */ ConfirmationPopup)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar ConfirmationPopup = props => {\n  var _a, _b, _c, _d, _e;\n  if (!props.isVisible) return null;\n  // Use buttons from props if available, otherwise use defaults\n  var buttons = props.buttons && props.buttons.length > 0 ? props.buttons : [{\n    text: \"YES, DELETE\",\n    color: \"#E00800\",\n    backgroundColor: \"#FCE6E6\",\n    FontFamily: \"Arial\",\n    FontWeight: 700,\n    FontSize: 14\n  }, {\n    text: \"NO, KEEP EDITING\",\n    color: \"#5E5A6A\",\n    backgroundColor: \"#FFFFFF\",\n    FontFamily: \"Arial\",\n    FontWeight: 700,\n    FontSize: 14\n  }];\n  var formatDimension = dim => {\n    if (!dim) return undefined;\n    return /^\\d+$/.test(dim) ? \"\".concat(dim, \"px\") : dim;\n  };\n  var containerStyle = {\n    width: (_a = formatDimension(props.popUpWidth)) !== null && _a !== void 0 ? _a : \"460px\",\n    height: (_b = formatDimension(props.popUpHeight)) !== null && _b !== void 0 ? _b : buttons.length === 1 ? \"258px\" : \"310px\"\n  };\n  var overlayStyle = {\n    backgroundColor: (_c = props.overlayBackgroundColor) !== null && _c !== void 0 ? _c : \"rgba(25, 19, 41, 0.4)\",\n    width: props.componentWidth ? \"\".concat(props.componentWidth, \"px\") : \"100%\",\n    height: props.componentHeight ? \"\".concat(props.componentHeight, \"px\") : \"100%\"\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"popup-overlay\",\n    style: overlayStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"popup-container\",\n    style: containerStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    className: \"close-button\",\n    onClick: () => props.onButtonClick(\"CLOSE\"),\n    \"aria-label\": \"Close\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    width: \"24\",\n    height: \"24\",\n    viewBox: \"0 0 24 24\",\n    fill: \"none\",\n    xmlns: \"http://www.w3.org/2000/svg\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M18.354 17.646C18.549 17.841 18.549 18.158 18.354 18.353C18.256 18.451 18.128 18.499 18 18.499C17.872 18.499 17.744 18.45 17.646 18.353L12 12.707L6.35401 18.353C6.25601 18.451 6.12801 18.499 6.00001 18.499C5.87201 18.499 5.74401 18.45 5.64601 18.353C5.45101 18.158 5.45101 17.841 5.64601 17.646L11.292 12L5.64601 6.35401C5.45101 6.15901 5.45101 5.84198 5.64601 5.64698C5.84101 5.45198 6.15801 5.45198 6.35301 5.64698L11.999 11.293L17.645 5.64698C17.84 5.45198 18.157 5.45198 18.352 5.64698C18.547 5.84198 18.547 6.15901 18.352 6.35401L12.707 12L18.354 17.646Z\",\n    fill: \"#191329\"\n  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"popup-content-wrapper\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"header-section\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"icon-wrapper\"\n  }, props.svgIcon ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"icon-svg\",\n    dangerouslySetInnerHTML: {\n      __html: props.svgIcon\n    }\n  })) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    className: \"icon-svg\",\n    width: \"32\",\n    height: \"32\",\n    viewBox: \"0 0 32 32\",\n    fill: \"none\",\n    xmlns: \"http://www.w3.org/2000/svg\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    fillRule: \"evenodd\",\n    clipRule: \"evenodd\",\n    d: \"M16 29C23.1797 29 29 23.1797 29 16C29 8.8203 23.1797 3 16 3C8.8203 3 3 8.8203 3 16C3 23.1797 8.8203 29 16 29ZM16 22C16.8284 22 17.5 21.3284 17.5 20.5C17.5 19.6716 16.8284 19 16 19C15.1716 19 14.5 19.6716 14.5 20.5C14.5 21.3284 15.1716 22 16 22ZM14.5 8V17H17.5V8H14.5Z\",\n    fill: \"currentColor\"\n  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"title-section\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h1\", {\n    className: \"popup-heading\"\n  }, (_d = props.heading) !== null && _d !== void 0 ? _d : \"Are You Sure?\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"popup-description\"\n  }, (_e = props.description) !== null && _e !== void 0 ? _e : \"Are you sure you want to delete this Template?\"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"buttons-footer\"\n  }, buttons.map((btn, index) => {\n    var _a, _b;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n      key: index,\n      className: index === 0 ? \"action-btn\" : \"cancel-btn\",\n      style: {\n        color: btn.color,\n        backgroundColor: btn.backgroundColor,\n        fontFamily: (_a = btn.FontFamily) !== null && _a !== void 0 ? _a : 'Arial',\n        fontWeight: (_b = btn.FontWeight) !== null && _b !== void 0 ? _b : index === 0 ? 700 : 600,\n        fontSize: btn.FontSize ? /^\\d+$/.test(btn.FontSize.toString()) ? \"\".concat(btn.FontSize, \"px\") : btn.FontSize : '14px'\n      },\n      onClick: () => props.onButtonClick(btn.text)\n    }, btn.text);\n  })))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./confirmationPopUp/ConfirmationPopup.tsx?\n}");

/***/ },

/***/ "./confirmationPopUp/index.ts"
/*!************************************!*\
  !*** ./confirmationPopUp/index.ts ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   confirmationPopUp: () => (/* binding */ confirmationPopUp)\n/* harmony export */ });\n/* harmony import */ var _ConfirmationPopup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConfirmationPopup */ \"./confirmationPopUp/ConfirmationPopup.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass confirmationPopUp {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.selectedButtonText = \"\";\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f;\n    var buttons = [];\n    try {\n      if (context.parameters.ButtonsJson.raw) {\n        buttons = JSON.parse(context.parameters.ButtonsJson.raw);\n      }\n    } catch (e) {\n      console.error(\"Failed to parse ButtonsJson\", e);\n    }\n    var props = {\n      heading: (_a = context.parameters.Heading.raw) !== null && _a !== void 0 ? _a : undefined,\n      description: (_b = context.parameters.Description.raw) !== null && _b !== void 0 ? _b : undefined,\n      buttons: buttons,\n      isVisible: context.parameters.IsVisible.raw,\n      onButtonClick: text => {\n        this.selectedButtonText = text;\n        this.notifyOutputChanged();\n      },\n      popUpWidth: (_c = context.parameters.PopUpWidth.raw) !== null && _c !== void 0 ? _c : undefined,\n      popUpHeight: (_d = context.parameters.PopUpHeight.raw) !== null && _d !== void 0 ? _d : undefined,\n      overlayBackgroundColor: (_e = context.parameters.OverlayBackgroundColor.raw) !== null && _e !== void 0 ? _e : undefined,\n      svgIcon: (_f = context.parameters.SvgIcon.raw) !== null && _f !== void 0 ? _f : undefined,\n      componentWidth: context.mode.allocatedWidth,\n      componentHeight: context.mode.allocatedHeight\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_ConfirmationPopup__WEBPACK_IMPORTED_MODULE_0__.ConfirmationPopup, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      SelectedButtonText: this.selectedButtonText\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./confirmationPopUp/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./confirmationPopUp/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('confirmationPopUp.confirmationPopUp', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.confirmationPopUp);
} else {
	var confirmationPopUp = confirmationPopUp || {};
	confirmationPopUp.confirmationPopUp = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.confirmationPopUp;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}