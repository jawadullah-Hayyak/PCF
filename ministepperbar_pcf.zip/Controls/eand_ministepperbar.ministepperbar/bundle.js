/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ministepperbar/Stepper.tsx"
/*!************************************!*\
  !*** ./ministepperbar/Stepper.tsx ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Stepper: () => (/* binding */ Stepper)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar Stepper = props => {\n  var [parsedItems, setParsedItems] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [internalSelectedId, setInternalSelectedId] = react__WEBPACK_IMPORTED_MODULE_0__.useState(props.selectedId);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    try {\n      if (props.items) {\n        var items = JSON.parse(props.items);\n        if (Array.isArray(items)) {\n          setParsedItems(items);\n        }\n      }\n    } catch (e) {\n      console.error(\"Failed to parse items JSON\", e);\n    }\n  }, [props.items]);\n  // Sync internal state with props, but only if props change\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    setInternalSelectedId(props.selectedId);\n  }, [props.selectedId]);\n  // Handle default selection\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (parsedItems.length > 0) {\n      var currentItemExists = parsedItems.some(item => item.Id === internalSelectedId);\n      if (!internalSelectedId || !currentItemExists) {\n        var firstId = parsedItems[0].Id;\n        setInternalSelectedId(firstId);\n        props.onStepClick(firstId);\n      }\n    }\n  }, [parsedItems, internalSelectedId, props]);\n  // Figma based styles\n  var containerStyle = {\n    display: 'flex',\n    flexDirection: 'row',\n    alignItems: 'center',\n    padding: '0px',\n    height: '25px',\n    width: '100%',\n    fontFamily: 'Arial'\n  };\n  var separatorContainerStyle = {\n    display: 'flex',\n    flexDirection: 'row',\n    justifyContent: 'center',\n    alignItems: 'center',\n    padding: '0px',\n    gap: '10px',\n    width: '18px',\n    height: '18px',\n    flex: 'none',\n    flexGrow: 0\n  };\n  var separatorStyle = {\n    color: '#BAB8BF',\n    fontSize: '14px'\n  };\n  var handleStepClick = id => {\n    setInternalSelectedId(id);\n    props.onStepClick(id);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: containerStyle\n  }, parsedItems.map((item, index) => {\n    var _a;\n    var isSelected = item.Id === internalSelectedId;\n    var isLast = index === parsedItems.length - 1;\n    // Base style for the item container\n    var itemContainerStyle = {\n      display: 'flex',\n      flexDirection: 'row',\n      justifyContent: 'center',\n      alignItems: 'center',\n      padding: '2px 9px',\n      gap: '10px',\n      height: '25px',\n      borderRadius: '20px',\n      cursor: 'pointer',\n      flex: 'none',\n      flexGrow: 0,\n      background: isSelected ? '#F6F6F7' : '#EFEEF0'\n    };\n    // Style for the text\n    var textStyle = {\n      fontFamily: 'Arial',\n      fontStyle: 'normal',\n      fontWeight: 400,\n      fontSize: props.fontSize ? \"\".concat(props.fontSize, \"px\") : '14px',\n      lineHeight: '150%',\n      letterSpacing: '0.015em',\n      textTransform: 'capitalize',\n      margin: 0,\n      color: isSelected ? '#E00800' : (_a = props.fontColor) !== null && _a !== void 0 ? _a : '#5E5A6A'\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n      key: item.Id\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      onClick: () => handleStepClick(item.Id),\n      style: itemContainerStyle\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: textStyle\n    }, item.Title)), !isLast && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: separatorContainerStyle\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: separatorStyle\n    }, \"/\"))));\n  }));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ministepperbar/Stepper.tsx?\n}");

/***/ },

/***/ "./ministepperbar/index.ts"
/*!*********************************!*\
  !*** ./ministepperbar/index.ts ***!
  \*********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ministepperbar: () => (/* binding */ ministepperbar)\n/* harmony export */ });\n/* harmony import */ var _Stepper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Stepper */ \"./ministepperbar/Stepper.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass ministepperbar {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    var _a;\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Initialize selectedId from initial props if available, or empty string\n    this._selectedId = (_a = context.parameters.selectedId.raw) !== null && _a !== void 0 ? _a : \"\";\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    // Update local state if the context provides a new value (allowing external control to override)\n    // Note: handling both internal state (click) and external state (property update) can be tricky.\n    // For now, we trust the external property if it changes, but also allow internal clicks to update the outputs.\n    var _a, _b, _c, _d, _e, _f;\n    // Use the raw value from context if it exists, otherwise fall back to internal state\n    var selectedId = (_a = context.parameters.selectedId.raw) !== null && _a !== void 0 ? _a : this._selectedId;\n    var props = {\n      items: (_b = context.parameters.items.raw) !== null && _b !== void 0 ? _b : \"[]\",\n      selectedId: selectedId !== null && selectedId !== void 0 ? selectedId : \"\",\n      onStepClick: this.onStepClick.bind(this),\n      fontSize: (_d = (_c = context.parameters.fontSize) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : 14,\n      fontColor: (_f = (_e = context.parameters.fontColor) === null || _e === void 0 ? void 0 : _e.raw) !== null && _f !== void 0 ? _f : \"#5E5A6A\"\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_Stepper__WEBPACK_IMPORTED_MODULE_0__.Stepper, props);\n  }\n  onStepClick(id) {\n    this._selectedId = id;\n    this.notifyOutputChanged();\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      selectedId: this._selectedId\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ministepperbar/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ministepperbar/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ministepperbar.ministepperbar', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ministepperbar);
} else {
	var ministepperbar = ministepperbar || {};
	ministepperbar.ministepperbar = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ministepperbar;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}