/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./SearchComponent/FilterIcon.tsx"
/*!****************************************!*\
  !*** ./SearchComponent/FilterIcon.tsx ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FilterIcon: () => (/* binding */ FilterIcon)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar FilterIcon = () => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n  width: \"24\",\n  height: \"24\",\n  viewBox: \"0 0 24 24\",\n  fill: \"none\",\n  xmlns: \"http://www.w3.org/2000/svg\"\n}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M22 7H2\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M19 17H5\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M8 7V5.5\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M8 8.5V7\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M16 17V15.5\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M16 18.5V17\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M12 12H13\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M2 12H8\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M17 12H22\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M13 10.5V13.5\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n})));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchComponent/FilterIcon.tsx?\n}");

/***/ },

/***/ "./SearchComponent/MicIcon.tsx"
/*!*************************************!*\
  !*** ./SearchComponent/MicIcon.tsx ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   MicIcon: () => (/* binding */ MicIcon)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar MicIcon = () => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n  width: \"20\",\n  height: \"20\",\n  viewBox: \"0 0 24 24\",\n  fill: \"none\",\n  xmlns: \"http://www.w3.org/2000/svg\"\n}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M12 2C10.3431 2 9 3.34315 9 5V11C9 12.6569 10.3431 14 12 14C13.6569 14 15 12.6569 15 11V5C15 3.34315 13.6569 2 12 2Z\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M19 10V11C19 14.866 15.866 18 12 18C8.13401 18 5 14.866 5 11V10\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M12 18V22\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M10 22H14\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n})));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchComponent/MicIcon.tsx?\n}");

/***/ },

/***/ "./SearchComponent/SearchComponent.tsx"
/*!*********************************************!*\
  !*** ./SearchComponent/SearchComponent.tsx ***!
  \*********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SearchComponent: () => (/* binding */ SearchComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _FilterIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FilterIcon */ \"./SearchComponent/FilterIcon.tsx\");\n/* harmony import */ var _SearchIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SearchIcon */ \"./SearchComponent/SearchIcon.tsx\");\n/* harmony import */ var _MicIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./MicIcon */ \"./SearchComponent/MicIcon.tsx\");\n\n\n\n\n\nvar useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.makeStyles)({\n  root: {\n    display: 'flex',\n    flexDirection: 'column',\n    justifyContent: 'space-between',\n    padding: '6px',\n    width: '100%',\n    height: '100%',\n    boxSizing: 'border-box'\n  },\n  titleContainer: {\n    display: 'flex',\n    flexDirection: 'column',\n    gap: '16px'\n  },\n  title: {\n    fontFamily: '\"SuisseIntl\", \"Segoe UI\", \"Segoe UI Web (West European)\", \"Segoe UI\", -apple-system, BlinkMacSystemFont, Roboto, \"Helvetica Neue\", sans-serif',\n    fontSize: '24px',\n    fontWeight: '300',\n    lineHeight: '34px',\n    letterSpacing: '0%',\n    color: '#191329'\n  },\n  subtitle: {\n    fontFamily: '\"SuisseIntl\", \"Segoe UI\", \"Segoe UI Web (West European)\", \"Segoe UI\", -apple-system, BlinkMacSystemFont, Roboto, \"Helvetica Neue\", sans-serif',\n    fontSize: '32px',\n    fontWeight: '300',\n    lineHeight: '44px',\n    letterSpacing: '0%',\n    color: '#5E5A6A'\n  },\n  controlsContainer: {\n    display: 'flex',\n    flexDirection: 'row',\n    alignItems: 'center',\n    gap: '12px',\n    width: '100%'\n  },\n  searchBar: {\n    display: 'flex',\n    flexDirection: 'row',\n    alignItems: 'center',\n    backgroundColor: '#FFFFFF',\n    flexGrow: 1,\n    borderRadius: '50px',\n    padding: '12px 16px',\n    boxShadow: '0px 0px 24px 0px #19132908'\n  },\n  inputControl: {\n    border: 'none',\n    width: '100%',\n    padding: '0 10px',\n    backgroundColor: 'transparent',\n    fontSize: '14px',\n    fontWeight: '300',\n    lineHeight: '20px',\n    letterSpacing: '0%',\n    ':focus-visible': {\n      outline: 'none'\n    },\n    '::placeholder': {\n      fontFamily: '\"SuisseIntl\", \"Segoe UI\", \"Segoe UI Web (West European)\", \"Segoe UI\", -apple-system, BlinkMacSystemFont, Roboto, \"Helvetica Neue\", sans-serif',\n      fontWeight: '300',\n      fontSize: '14px',\n      lineHeight: '20px',\n      letterSpacing: '0%',\n      color: '#5E5A6A'\n    }\n  },\n  iconButton: {\n    color: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralForeground1,\n    cursor: 'pointer',\n    backgroundColor: 'transparent',\n    border: 'none',\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center'\n    // padding: '4px',\n  },\n  searchIconWrapper: {\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center'\n    // padding: '4px',\n  },\n  filterButton: {\n    display: 'flex',\n    alignItems: 'center',\n    justifyContent: 'center',\n    backgroundColor: '#FFFFFF',\n    width: '44px',\n    height: '44px',\n    minWidth: '44px',\n    minHeight: '44px',\n    flexShrink: 0,\n    borderRadius: '50%',\n    boxShadow: '0px 0px 24px 0px #19132908',\n    border: 'none',\n    cursor: 'pointer',\n    ':hover': {\n      backgroundColor: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.tokens.colorNeutralBackground1Hover\n    }\n  }\n});\nvar SearchComponent = props => {\n  var _a;\n  var styles = useStyles();\n  var rootStyle = {\n    width: props.width ? \"\".concat(props.width, \"px\") : '100%',\n    height: props.height && props.height > -1 ? \"\".concat(props.height, \"px\") : '100%',\n    backgroundColor: (_a = props.backgroundColor) !== null && _a !== void 0 ? _a : 'transparent'\n  };\n  var handleInputChange = event => {\n    // Use default if value is missing for some reason\n    props.onSearchChange(event.target.value);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.FluentProvider, {\n    theme: _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.webLightTheme\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.root,\n    style: rootStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.titleContainer\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Text, {\n    className: styles.title\n  }, props.title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Text, {\n    className: styles.subtitle\n  }, props.subtitle)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.controlsContainer\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.searchBar\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.searchIconWrapper\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_SearchIcon__WEBPACK_IMPORTED_MODULE_3__.SearchIcon, null)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"input\", {\n    className: styles.inputControl,\n    type: \"text\",\n    placeholder: props.placeholder,\n    value: props.searchText || '',\n    onChange: handleInputChange\n  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    type: \"button\",\n    className: styles.iconButton,\n    onClick: props.onMicClick\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MicIcon__WEBPACK_IMPORTED_MODULE_4__.MicIcon, null))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    type: \"button\",\n    className: styles.filterButton,\n    onClick: props.onFilterClick\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_FilterIcon__WEBPACK_IMPORTED_MODULE_2__.FilterIcon, null)))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchComponent/SearchComponent.tsx?\n}");

/***/ },

/***/ "./SearchComponent/SearchIcon.tsx"
/*!****************************************!*\
  !*** ./SearchComponent/SearchIcon.tsx ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SearchIcon: () => (/* binding */ SearchIcon)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar SearchIcon = () => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n  width: \"20\",\n  height: \"20\",\n  viewBox: \"0 0 24 24\",\n  fill: \"none\",\n  xmlns: \"http://www.w3.org/2000/svg\"\n}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n  d: \"M21 21L16.65 16.65\",\n  stroke: \"#191329\",\n  strokeWidth: \"1.5\",\n  strokeLinecap: \"round\",\n  strokeLinejoin: \"round\"\n})));\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchComponent/SearchIcon.tsx?\n}");

/***/ },

/***/ "./SearchComponent/index.ts"
/*!**********************************!*\
  !*** ./SearchComponent/index.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SearchComponent: () => (/* binding */ SearchComponent)\n/* harmony export */ });\n/* harmony import */ var _SearchComponent__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SearchComponent */ \"./SearchComponent/SearchComponent.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass SearchComponent {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.searchText = \"\";\n    this.filterTrigger = false;\n    this.micTrigger = false;\n    this.handleSearchChange = newValue => {\n      this.searchText = newValue;\n      this.notifyOutputChanged();\n    };\n    this.handleFilterClick = () => {\n      // Toggle the trigger value\n      this.filterTrigger = !this.filterTrigger;\n      this.notifyOutputChanged();\n    };\n    this.handleMicClick = () => {\n      // Toggle the trigger value\n      this.micTrigger = !this.micTrigger;\n      this.notifyOutputChanged();\n    };\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    var _a, _b;\n    this.notifyOutputChanged = notifyOutputChanged;\n    context.mode.trackContainerResize(true);\n    // Initialize bound properties\n    this.searchText = (_b = (_a = context.parameters.SearchText) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"\";\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e;\n    // Prepare props\n    var props = {\n      title: (_a = context.parameters.Title.raw) !== null && _a !== void 0 ? _a : \"Dashboard\",\n      subtitle: (_b = context.parameters.Subtitle.raw) !== null && _b !== void 0 ? _b : \"What can we help you with?\",\n      placeholder: (_c = context.parameters.PlaceholderText.raw) !== null && _c !== void 0 ? _c : \"Search for services...\",\n      searchText: (_d = context.parameters.SearchText.raw) !== null && _d !== void 0 ? _d : \"\",\n      // Use the value from context to ensure single source of truth\n      width: context.mode.allocatedWidth,\n      height: context.mode.allocatedHeight,\n      onSearchChange: this.handleSearchChange,\n      onFilterClick: this.handleFilterClick,\n      onMicClick: this.handleMicClick,\n      backgroundColor: (_e = context.parameters.BackgroundColor.raw) !== null && _e !== void 0 ? _e : undefined\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_SearchComponent__WEBPACK_IMPORTED_MODULE_0__.SearchComponent, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      SearchText: this.searchText,\n      FilterTrigger: this.filterTrigger,\n      MicTrigger: this.micTrigger\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SearchComponent/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./SearchComponent/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Hayyak.SearchComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SearchComponent);
} else {
	var Hayyak = Hayyak || {};
	Hayyak.SearchComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SearchComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}