/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./confirmationPopUp/ConfirmationPopup.tsx"
/*!*************************************************!*\
  !*** ./confirmationPopUp/ConfirmationPopup.tsx ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ConfirmationPopup: () => (/* binding */ ConfirmationPopup)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nvar ConfirmationPopup = props => {\n  var _a, _b, _c;\n  if (!props.isVisible) return null;\n  var buttons = props.buttons && props.buttons.length > 0 ? props.buttons : [{\n    text: \"DONE\",\n    color: \"#ff3b3b\",\n    backgroundColor: \"#fff0f0\"\n  }];\n  var formatDimension = (dim, defaultValue) => {\n    if (!dim) return defaultValue;\n    // If it's just a number, append 'px'\n    return /^\\d+$/.test(dim) ? \"\".concat(dim, \"px\") : dim;\n  };\n  var popupStyle = {\n    width: formatDimension(props.popUpWidth, \"300px\"),\n    height: formatDimension(props.popUpHeight, \"300px\"),\n    display: 'flex',\n    flexDirection: 'column',\n    justifyContent: 'center',\n    maxWidth: '90%',\n    maxHeight: '90%',\n    overflow: 'hidden'\n  };\n  var overlayStyle = {\n    backgroundColor: (_a = props.overlayBackgroundColor) !== null && _a !== void 0 ? _a : \"rgba(0, 0, 0, 0.4)\"\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"popup-overlay\",\n    style: overlayStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"popup-container\",\n    style: popupStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"icon-container\"\n  }, props.svgIcon ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    dangerouslySetInnerHTML: {\n      __html: props.svgIcon\n    }\n  })) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n    className: \"checkmark-icon\",\n    width: \"32\",\n    height: \"32\",\n    viewBox: \"0 0 24 24\",\n    fill: \"none\",\n    xmlns: \"http://www.w3.org/2000/svg\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n    d: \"M20 6L9 17L4 12\",\n    stroke: \"currentColor\",\n    strokeWidth: \"3\",\n    strokeLinecap: \"round\",\n    strokeLinejoin: \"round\"\n  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h1\", {\n    className: \"popup-heading\"\n  }, (_b = props.heading) !== null && _b !== void 0 ? _b : \"Entity Created\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"p\", {\n    className: \"popup-description\"\n  }, (_c = props.description) !== null && _c !== void 0 ? _c : \"You have successfully created the entity. You can now assign admin and parent to this entity.\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: \"buttons-container\",\n    style: {\n      display: 'flex',\n      flexDirection: 'column',\n      gap: '12px',\n      width: '100%'\n    }\n  }, buttons.map((btn, index) => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"button\", {\n    key: index,\n    className: \"done-button\",\n    style: {\n      color: btn.color,\n      backgroundColor: btn.backgroundColor,\n      width: '100%'\n    },\n    onClick: () => props.onButtonClick(btn.text)\n  }, btn.text))))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./confirmationPopUp/ConfirmationPopup.tsx?\n}");

/***/ },

/***/ "./confirmationPopUp/index.ts"
/*!************************************!*\
  !*** ./confirmationPopUp/index.ts ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   confirmationPopUp: () => (/* binding */ confirmationPopUp)\n/* harmony export */ });\n/* harmony import */ var _ConfirmationPopup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ConfirmationPopup */ \"./confirmationPopUp/ConfirmationPopup.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass confirmationPopUp {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.selectedButtonText = \"\";\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f;\n    var buttons = [];\n    try {\n      if (context.parameters.ButtonsJson.raw) {\n        buttons = JSON.parse(context.parameters.ButtonsJson.raw);\n      }\n    } catch (e) {\n      console.error(\"Failed to parse ButtonsJson\", e);\n    }\n    var props = {\n      heading: (_a = context.parameters.Heading.raw) !== null && _a !== void 0 ? _a : undefined,\n      description: (_b = context.parameters.Description.raw) !== null && _b !== void 0 ? _b : undefined,\n      buttons: buttons,\n      isVisible: context.parameters.IsVisible.raw,\n      onButtonClick: text => {\n        this.selectedButtonText = text;\n        this.notifyOutputChanged();\n      },\n      popUpWidth: (_c = context.parameters.PopUpWidth.raw) !== null && _c !== void 0 ? _c : undefined,\n      popUpHeight: (_d = context.parameters.PopUpHeight.raw) !== null && _d !== void 0 ? _d : undefined,\n      overlayBackgroundColor: (_e = context.parameters.OverlayBackgroundColor.raw) !== null && _e !== void 0 ? _e : undefined,\n      svgIcon: (_f = context.parameters.SvgIcon.raw) !== null && _f !== void 0 ? _f : undefined\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_ConfirmationPopup__WEBPACK_IMPORTED_MODULE_0__.ConfirmationPopup, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      SelectedButtonText: this.selectedButtonText\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./confirmationPopUp/index.ts?\n}");

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./confirmationPopUp/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('confirmationPopUp.confirmationPopUp', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.confirmationPopUp);
} else {
	var confirmationPopUp = confirmationPopUp || {};
	confirmationPopUp.confirmationPopUp = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.confirmationPopUp;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}