/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ProgressBar/ProgressBar.tsx"
/*!*************************************!*\
  !*** ./ProgressBar/ProgressBar.tsx ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ProgressBarComponent: () => (/* binding */ ProgressBarComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react/lib/Icons\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\n// Explicitly initialize icons\n(0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.initializeIcons)();\n// Default/Base Colors\nvar inactiveColor = '#e1dfdd'; // Light grey\nvar subTextColor = '#605e5c';\n/**\r\n * Root container for the entire control.\r\n * Fixed height 122px.\r\n */\nvar rootContainerStyle = {\n  width: '100%',\n  height: '122px',\n  display: 'flex',\n  alignItems: 'center',\n  justifyContent: 'center',\n  background: 'transparent',\n  margin: 0,\n  padding: 0,\n  border: 'none',\n  boxSizing: 'border-box',\n  overflow: 'visible'\n};\n/**\r\n * The white card.\r\n * overflowX: 'auto' will ONLY show a scrollbar if the content overflows (small screens).\r\n */\nvar cardStyle = {\n  display: 'flex',\n  flexDirection: 'row',\n  alignItems: 'center',\n  justifyContent: 'space-between',\n  width: '100%',\n  height: '108px',\n  background: '#ffffff',\n  borderRadius: '20px',\n  border: 'none',\n  outline: 'none',\n  boxShadow: '0 4px 15px rgba(0,0,0,0.08)',\n  boxSizing: 'border-box',\n  overflowX: 'auto',\n  overflowY: 'hidden',\n  position: 'relative',\n  padding: '0 50px',\n  paddingTop: '20px',\n  scrollbarWidth: 'thin'\n};\nvar circleSize = 40;\nvar itemMinWidth = 40;\nvar labelWidth = 140;\nvar ProgressBarComponent = props => {\n  var [steps, setSteps] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var activeColor = props.themeColor || '#d13438'; // Defaulting to the brand red\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (props.itemsJson) {\n      try {\n        var parsed = JSON.parse(props.itemsJson);\n        if (Array.isArray(parsed)) {\n          setSteps(parsed);\n        }\n      } catch (e) {\n        console.error(\"Invalid JSON\", e);\n      }\n    }\n  }, [props.itemsJson]);\n  if (!steps.length) {\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        textAlign: 'center',\n        padding: '20px',\n        color: subTextColor\n      }\n    }, \"No steps to display\");\n  }\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: rootContainerStyle\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"style\", null, \"\\n                    div::-webkit-scrollbar {\\n                        height: 5px;\\n                    }\\n                    div::-webkit-scrollbar-track {\\n                        background: transparent;\\n                        margin: 20px;\\n                    }\\n                    div::-webkit-scrollbar-thumb {\\n                        background: rgba(225, 223, 221, 0.6);\\n                        border-radius: 10px;\\n                    }\\n                    div::-webkit-scrollbar-thumb:hover {\\n                        background: \".concat(activeColor, \";\\n                    }\\n                \")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: cardStyle\n  }, steps.map((step, index) => {\n    var isLast = index === steps.length - 1;\n    var isCompleted = step.status === 'completed';\n    var isActive = step.status === 'active';\n    var isRejected = step.status === 'rejected';\n    var circleBorderColor = isCompleted || isActive || isRejected ? activeColor : inactiveColor;\n    var textColorToUse = isActive || isCompleted || isRejected ? activeColor : subTextColor;\n    var lineColor = isCompleted ? activeColor : inactiveColor;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n      key: index\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        display: 'flex',\n        alignItems: 'center',\n        justifyContent: 'center',\n        position: 'relative',\n        flex: '0 0 auto',\n        width: itemMinWidth,\n        height: circleSize,\n        overflow: 'visible'\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        position: 'absolute',\n        bottom: '100%',\n        marginBottom: '10px',\n        left: '50%',\n        transform: 'translateX(-50%)',\n        width: labelWidth,\n        textAlign: 'center',\n        pointerEvents: 'none'\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {\n      styles: {\n        root: {\n          color: textColorToUse,\n          fontWeight: 600,\n          fontFamily: \"'Suisse Int\\\\'l', -apple-system, sans-serif\",\n          fontSize: '12px',\n          lineHeight: '16px',\n          whiteSpace: 'nowrap',\n          overflow: 'hidden',\n          textOverflow: 'ellipsis',\n          display: 'block'\n        }\n      }\n    }, step.label)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        width: circleSize,\n        height: circleSize,\n        borderRadius: '50%',\n        border: \"2px solid \".concat(circleBorderColor),\n        display: 'flex',\n        alignItems: 'center',\n        justifyContent: 'center',\n        backgroundColor: '#ffffff',\n        zIndex: 2,\n        boxSizing: 'border-box'\n      }\n    }, isCompleted && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.FontIcon, {\n      iconName: \"CheckMark\",\n      style: {\n        color: activeColor,\n        fontSize: 18,\n        fontWeight: 'bold'\n      }\n    }), isRejected && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.FontIcon, {\n      iconName: \"Cancel\",\n      style: {\n        color: activeColor,\n        fontSize: 18,\n        fontWeight: 'bold'\n      }\n    }))), !isLast && (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        flex: '1 1 80px',\n        height: 2,\n        minWidth: '60px',\n        backgroundColor: lineColor,\n        zIndex: 1,\n        marginLeft: 4,\n        marginRight: 4\n      }\n    })));\n  })));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ProgressBar/ProgressBar.tsx?\n}");

/***/ },

/***/ "./ProgressBar/index.ts"
/*!******************************!*\
  !*** ./ProgressBar/index.ts ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ProgressBar: () => (/* binding */ ProgressBar)\n/* harmony export */ });\n/* harmony import */ var _ProgressBar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProgressBar */ \"./ProgressBar/ProgressBar.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _fluentui_react_lib_Icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fluentui/react/lib/Icons */ \"@fluentui/react/lib/Icons\");\n/* harmony import */ var _fluentui_react_lib_Icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_lib_Icons__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n(0,_fluentui_react_lib_Icons__WEBPACK_IMPORTED_MODULE_2__.initializeIcons)();\nclass ProgressBar {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\r\n   * Called when any value in the property bag has changed.\r\n   */\n  updateView(context) {\n    var props = {\n      itemsJson: context.parameters.items.raw || \"[]\",\n      themeColor: context.parameters.activeColor.raw || \"#d13438\"\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_ProgressBar__WEBPACK_IMPORTED_MODULE_0__.ProgressBarComponent, props);\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree.\r\n   */\n  destroy() {}\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ProgressBar/index.ts?\n}");

/***/ },

/***/ "@fluentui/react/lib/Icons"
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
(module) {

module.exports = FluentUIReactv8290;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ProgressBar/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('FluentUIControls.ProgressBar', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ProgressBar);
} else {
	var FluentUIControls = FluentUIControls || {};
	FluentUIControls.ProgressBar = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ProgressBar;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}